#responsible for drawing all the background non-interactable stuff
import pygame, math, random
from Utils import Utils
from gameSprite import GameSprite

class Background():
    def getColors(self, data, length):
        list = []
        for i in range(length):
            frac = i/(length-1)
            list.append(Utils.interpolateColor(Utils.BLUE,Utils.DARKBLUE,frac))
        return list

    def __init__(self, data):
        self.landHeight = data.landHeight
        self.waterLine = -1 * data.screenY
        self.waterColor = Utils.BLUE
        self.colors = 30 #how many colors in the water gradient
        self.waterColors = self.getColors(data, self.colors) # list

    #if y coordinate of top edge is negative, then it's above the water
    #if it's positive then we don't see sky
    def update(self, data):
        self.waterLine = -1 * data.screenY
        index = math.floor(data.player.y / (data.STAGEHEIGHT/ self.colors))
        if index < 0: index = 0
        self.waterColor = self.waterColors[index]


    def drawOcean(self, data, surface):
        surface.fill(self.waterColor)

    #just solid walls that extend beyond the edge of the playing field
    def drawWalls(self, data, surface):
        (screenX, screenY) = data.screenX, data.screenY
        if screenY + data.HEIGHT >= data.STAGEHEIGHT:
            pygame.draw.rect(surface, (0,0,0), 
                (0, data.STAGEHEIGHT-screenY, data.WIDTH, data.HEIGHT))
        if screenX < 0: #left wall
            pygame.draw.rect(surface, (0,0,0),
                (0, max(0,-1*screenY-self.landHeight), 0-screenX, data.HEIGHT))
        elif screenX > data.WIDTH:
            pygame.draw.rect(surface, (0,0,0),
                (data.STAGEWIDTH-screenX, max(0, -1*screenY-self.landHeight),
                 data.WIDTH, data.HEIGHT))


    def drawAll(self, data, surface):
        self.drawOcean(data, surface)
        self.drawWalls(data, surface)
