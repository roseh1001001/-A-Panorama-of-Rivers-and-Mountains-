#the class that generates terrain and saves it as an image
import pygame
import random, copy, math
from Utils import Utils



#Used midpoint displacement algorithm tutorial found at: 
#http://www.somethinghitme.com/2013/11/11/simple-2d-terrain-
#with-midpoint-displacement/
#code is original
class Terrain():

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.minHeight = self.height // 3 * 2 #floor of terrain
        self.maxHeight = 0
        self.iterations = 6 #1 at minimum
        self.bumpiness = 25
        self.dampening = 0.5 #higher = more jagged

        self.peakDist = 3 #islands cannot spawn right at edg
        self.yMargin = 60
        self.tunnelWidth = 60

        self.vertices = []
        self.terrainPoints = self.getTopPoints()
        self.canvas = pygame.Surface((self.width,self.height))
        #self.caveCoords = self.getCaveCoords()

    #returns a list of coordinates of the terrain along the top
    def getTopPoints(self):
        points = [(0,self.maxHeight)]
        numOfPoints = 16 #initial vertices, controls edge slope steepness

        peak = random.randint(5,numOfPoints-self.peakDist-1)

        #creating the basic outline with a random peak or two
        for i in range(1, numOfPoints):
            x = self.width / numOfPoints * i
            offset = Utils.randomRange(-1*self.bumpiness, self.bumpiness)
            y = self.maxHeight if (i==peak or i==peak+1) else self.minHeight
            points.append((x, y+offset))

        #using midpoint displacement
        for n in range(1, self.iterations):
            xWidth = (points[1][0] - points[0][0]) / 2
            newPoints = []
            offsetLimit = int(self.bumpiness * ( self.dampening**n ))
            #generate a bunch of new points
            for i in range(len(points)-1):
                x = points[i][0] + xWidth
                (y0, y1) = (points[i][1], points[i+1][1])
                interpolatedY = y0 + ( (y1-y0) / 2 )
                offset = Utils.randomRange(-1*offsetLimit, offsetLimit)
                y = interpolatedY + offset
                newPoints.append((x,y))

            #now fold them back into the points list alternatingly
            temp = []
            for i in range(len(newPoints)):
                temp.append(points[i])
                temp.append(newPoints[i])
            temp.append(points[-1])

            points = copy.copy(temp)

        points.append((self.width, 0))
        return points


    def drawBasicTerrain(self, surface, color):
        #adding bottom two corners
        self.vertices = ([(0, self.height)] + self.terrainPoints +
                         [(self.width, self.height)])
        surface.fill(Utils.WHITE)
        pygame.draw.polygon(surface, color, self.vertices)

    def newTerrain(self):
        self.terrainPoints = self.getTopPoints()

    def exportBg(self, fileName):
        self.drawBasicTerrain(self.canvas, Utils.GRAY)
        pygame.image.save(self.canvas, fileName+"_bg.png")

    def export(self, fileName):
        self.exportBg(fileName)

        self.drawBasicTerrain(self.canvas, Utils.BLACK)
        
        pygame.image.save(self.canvas, fileName+"_stage.png")
