import sys, pygame, random
from button import Button
from Background import Background
from Utils import Utils

pygame.init()

class Menu():
    def __init__(self, data):
        self.buttons = set()
        random.seed("42")
        self.oceanBg = Background(data)
        random.seed()
    
    def update(self, data, event):
        if event.type == pygame.USEREVENT+1:
            self.oceanBg.update(data)
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            for button in self.buttons:
                if button.rect.collidepoint(pos):
                    button.onClick(data)

    def draw(self, data, surface):
        self.oceanBg.drawOcean(data, surface)
        for button in self.buttons:
            button.draw(surface)

#Each actual menu in the game is a class inherited from Menu
class GameMenu(Menu):
    def __init__(self, data):
        super().__init__(data)
        def diveBtnFn(data):data.newDiveFn(data)
        diveBtn = Button('dive_button.png',data.WIDTH//2,data.HEIGHT//2, diveBtnFn, True, group=self.buttons)

        def backBtnFn(data):
            data.saveFn(data)
            data.gameMode = "SPLASH"
        backBtn = Button('main_menu_button.png', data.WIDTH//2,data.HEIGHT*3//4, backBtnFn, True, group=self.buttons)

class SplashMenu(Menu):
    def __init__(self, data):
        super().__init__(data)
        self.title = pygame.image.load('title.png')

        def newBtnFn(data):
            data.newGameFn(data)
        newBtn = Button('new_button.png',data.WIDTH//2,
                    data.HEIGHT//2, newBtnFn, True, group=self.buttons)

        def quitBtnFn(data):
            pygame.quit()
            sys.exit()
        quitBtn = Button('quit_button.png',data.WIDTH//2,
                data.HEIGHT*3//4, quitBtnFn, True, group=self.buttons)
############################
    def draw(self, data, surface):
        super().draw(data, surface)
        Utils.blitCenter(self.title, surface, (data.WIDTH//2, data.HEIGHT//6))
