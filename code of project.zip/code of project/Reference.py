import ImageWriter
import math
'''create reference here'''
pglst=["pg10.jpg","pg20.jpg","pg30.jpg","pg40.jpg","pg50.jpg"]
# reference=[]
# for filename in reference:
#     pic=ImageWriter.loadPicture(filename)
#     reference.append(pic)
# here warn that the loadpirture would not return anything
#so just use the filelist is enough

def nearblack(i,x,y):
    a=ImageWriter.loadPicture(pglst[i])
    color=ImageWriter.getColor(a,x,y)
    #set near black scale (0,0,0)
    if (color[0]+color[1]+color[2])/3<5:
        return True
    else:
        return False

#for object sprit
def isColliding(x0,y0,sprit):
    #sprit has got inheritance from...
    #such x0,y0 are the location of the imgae not the screen
    w=sprit.rect.width
    h=sprit.rect.height
    r=math.sqrt((w/2)**2+(h/2)**2)
    centerx=x0+w/2
    centery=y0+h/2
    number=int(sprit.school)-1
    if w>h:
        for i in range(x0,x0+w+1):
            for j in range(y0,y0+h+1):
                if (i-centerx)**2+(j-centery)**2<=r**2:
                    if nearblack(number,i,j):
                        #if data.operationofsprit==True: #need to be set
                        #     return True
                        # else:
                        return True
                    else:
                        return False
                else: return False



# if Reference.isColliding(data,boat)==True:
#     if data.operationofsprit==True:
#         boat.v = 0
#     elif data.operationofsprit==False:
#         boat.turn()