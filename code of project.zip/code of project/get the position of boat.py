import pygame

pygame.init()
screen = pygame.display.set_mode((1440, 663)
done = False
circles = []
clock = pygame.time.Clock()
while not done:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        done = True
                if event.type == pygame.MOUSEMOTION:
                    x,y = event.pos
                print (x,y))
        screen.fill([0,0,0])
        pygame.display.flip()

pygame.quit()