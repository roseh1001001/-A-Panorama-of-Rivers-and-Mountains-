import Tkinter as tk
import pygame, sys
import ImageWriter
import time

def Surface(a):
    speed = 24
    BLACK = (0, 0, 0)
    if a:
        pygame.init()
        surf = pygame.display.set_mode((1440, 663))
        pygame.display.set_caption('A Panorama of Rivers and Mountains')
        surf.fill(BLACK)

        pglst = ["pg1.jpg",
                 "pg2.jpg",
                 "pg3.jpg",
                 "pg4.jpg",
                 "pg5.jpg","pg6.jpg"]
        newpglst = []
        for i in pglst:
            b = pygame.image.load(i).convert()
            newpglst.append(b)
        timelst = [0]
        timelap = 0
        for j in newpglst:
            width = ImageWriter.getWidth(j)
            print width
            timelap += 1.0 * width / speed
            timelst.append(timelap)

        def move(i, time_passed):
            time= time_passed- timelst[i]
            width=ImageWriter.getWidth(newpglst[i])
            if (time >=0) and (time * speed <= 1440+width):
                surf.blit(newpglst[i], (1440 - time * speed, 0))


        def done(time_passed):
            move(0, time_passed)
            move(1, time_passed)
            move(2, time_passed)
            move(3, time_passed)
            move(4, time_passed)
            move(5, time_passed)

        start = time.time()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_s:
                    speed=0
                if event.type == pygame.KEYDOWN and event.key == pygame.K_n:
                    speed=24


            time_passed = time.time() - start

            done(time_passed)
            pygame.display.flip()
            pygame.display.update()



root= tk.Tk()
root.title('A Panorama of Rivers and Mountains')
root.geometry("1450x712")
canvas=tk.Canvas(root,width=1450,height=711,bg='white')
im=tk.PhotoImage(file='Overview.gif')
canvas.create_image(725,355,image=im)
canvas.bind_all("<Button-1>",Surface)
canvas.pack()
root.mainloop()
