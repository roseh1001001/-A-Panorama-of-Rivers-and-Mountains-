import pygame, random, math
from betweenboat import betweenBoat
from movingSprite import MovingSprite
from Utils import Utils
from Reference import Reference

class Boat(MovingSprite):
    WANDER = "wander"
    FOLLOW = "follow"
    FLEEING = "fleeing"
    REGROUP = "regroup"

    SPEEDS = {"wander": 13,
             "follow": 14,
             "fleeing": 22,
             "regroup": 15
            }

    ACCEL = 3
    DEACCEL =2

    def collideFn(self, data, x, y, boat):
        a=Utils()
        bb=betweenBoat(data, x, y, self.img, self.time_passed,self.school)
        r=Reference()

        if a.isRectOutOfStage(data, x, y,boat.rect.width,boat.rect.height,boat.STAGEWIDTH,boat.STAGEHEIGHT):
            return True
        if r.isColliding(x,y,boat):
            return True
        return bb.isCollidingLite(x, y, boat.mask)


    def __init__(self,data,x,y,imgPath,time_passed,school,direction=1, isLeader=False):
        super(Boat,self).__init__(data, x, y, imgPath,time_passed,school,Boat.SPEEDS["wander"],Boat.ACCEL, Boat.DEACCEL)

        self.direction = direction
        if direction == -1:
            self.flipSprite()
        self.school = school  #what school/pg the boat is in
        self.isLeader = isLeader
        self.mode = Boat.WANDER if (self.isLeader) else Boat.FOLLOW
        self.minTargetDist = 200
        self.maxTargetDist =500
        self.maxFollowDist = 100
        self.turnChance = 0.2 #how likely it is to turn when wandering
        self.threatDist = 100
        self.threatVel = 3.0 #how fast the player influence other boats
        self.maxTargetUpdateAttempts = 40
        self.operationofsprit=False
        self.updateScreenCoords()
        self.time_passed=time_passed

        #self.updateTarget()
        if self.school==1:
            self.STAGEHEIGHT = 661
            self.STAGEWIDTH = 3078
        elif self.school==2:
            self.STAGEHEIGHT = 661
            self.STAGEWIDTH = 3119
        elif self.school==3:
            self.STAGEHEIGHT = 661
            self.STAGEWIDTH = 3161
        elif self.school==4:
            self.STAGEHEIGHT = 661
            self.STAGEWIDTH = 3099
        elif self.school==5:
            self.STAGEHEIGHT = 661
            self.STAGEWIDTH = 3099
        # def __repr__(self):
        #     self.doMove(data)

    #return an angle but tends towards the horizontal, will never point up
    #or down more than 30 degrees
    def getRandomWanderAngle(self):
        left = Utils.randomRange(-1*math.pi/6, math.pi/6)
        right = Utils.randomRange(5/6*math.pi, 7/6*math.pi)
        if self.direction == 1:
            return Utils.randomChoice(right, left, self.turnChance)
        else:
            return Utils.randomChoice(left, right, self.turnChance)

    def getFleeingAngle(self, otherX, otherY):
        #opposite angle of the source
        oppAngle = Utils.getAngle(self.x, self.y, otherX, otherY) - math.pi
        return Utils.randomRange(oppAngle-math.pi/6, oppAngle+math.pi/6)

    def updateTargetVelocity(self):
        self.targetV = Boat.SPEEDS[self.mode]

    def coordsFromDistAngle(self, x, y, dist, angle):
        return (x + dist * math.cos(angle), y - dist * math.sin(angle))

    def justChooseAnyTarget(self):
        dist = random.randrange(0, self.maxTargetDist)
        a=Utils()
        angle = a.randomRange(0, 2*math.pi)
        return self.coordsFromDistAngle(self.x, self.y, dist, angle)

    def chooseNewTarget(self, data):
        if self.mode == Boat.WANDER:
            dist = random.randrange(self.minTargetDist, self.maxTargetDist)
            angle = self.getRandomWanderAngle()
            return self.coordsFromDistAngle(self.x, self.y, dist, angle)

        elif self.mode == Boat.FOLLOW:
            leader = self.getLeader(data)
            dist = random.randrange(0, self.maxFollowDist)
            a=Utils()
            angle = a.randomRange(0, 2*math.pi)
            return self.coordsFromDistAngle(leader.x, leader.y, dist, angle)

        elif self.mode == Boat.FLEEING:
            dist = random.randrange(self.minTargetDist, self.maxTargetDist)
            angle = self.getFleeingAngle(data.player.x, data.player.y)
            return self.coordsFromDistAngle(self.x, self.y, dist, angle)


    #try choosing new targets until you get a legal one
    def updateTarget(self, data):
        self.updateTargetVelocity()

        #pick target according to mode
        tries = 0
        while (tries < self.maxTargetUpdateAttempts):
            tries += 1
            (targetX, targetY) = self.chooseNewTarget(data)
            #this new target is fine


            if not self.collideFn(data, targetX, targetY, self):
                self.setTarget(targetX, targetY)
                return

        #failed to choose a target, just try going anywhere instead of
        #getting stuck forever
        while (True):
            (targetX, targetY) = self.justChooseAnyTarget()
            if not self.collideFn(data, targetX, targetY, self):
                self.setTarget(targetX, targetY)
                return

    def playerSensed(self, data):
        if data.player:
            a=Utils()
            return (data.player.v > self.threatVel and a.distance(self.x, self.y,
            data.player.x, data.player.y) < self.threatDist)

    def doMove(self, data):
        self.updateVelocity()
        a=Utils()
        oldDist = a.distanceSq(self.x, self.y, self.targetX, self.targetY)
        self.moveTowardsTarget()
        newDist = a.distanceSq(self.x, self.y, self.targetX, self.targetY)

        if self.playerSensed(data) and self.mode != Boat.FLEEING:
            self.mode = Boat.FLEEING
            self.updateTarget(data)

        if (newDist >= oldDist): #arrived at target
            if self.mode == Boat.FLEEING: #cools off
                self.mode = Boat.WANDER if (self.isLeader) else Boat.FOLLOW

            self.updateTarget(data)

    def getLeader(self,data):
        boats=data.boatalllst[self.school-1]
        a=random.choice(boats)
                #since form a spritegroup, the sprite unit would be gotten in a random way
        a.isLeader=True
        return a


    def isPositionLegal(self, data):
            for group in data.gameSpriteGroups:
                for i in group:
                    for j in group:
                        if i!=j:
                            return not (data.betweenboat.isColliding(i,j)) and not (Reference.isColliding(i)) and not (Reference.isColliding(j))

    def drawself(self,surf):
        if 0<= self.rect.x <=1440:
            surf.blit(self.image, (self.rect.x, self.rect.y))

