import pygame
from gameSprit import GameSprite

class betweenBoat(GameSprite):
    def __init__(self, data, x, y, img,time_passed,school):
        super(betweenBoat,self).__init__(data, x, y, img,time_passed,school)

    #other is a GameSprite
    def isColliding(self, other):

        #overlap function only takes ints
        #http://www.pygame.org/docs/ref/mask.html#pygame.mask.Mask.overlap_mask
        (offsetX, offsetY) = (int(other.x-self.x), int(other.y - self.y))
        #Returns a Mask the size of the original Mask containing only the overlapping pixels between Mask and othermask.
        overlap = self.mask.overlap(other.mask, (offsetX, offsetY))
        return (overlap != None)

    def isCollidingLite(self, x, y, mask):
        (offsetX, offsetY) = (int(x-self.x), int(y - self.y))
        overlap = self.mask.overlap(mask, (offsetX, offsetY))
        return (overlap != None)
