import math, random, pygame

class Utils():

    WHITE = (255,255,255)
    BLACK = (0,0,0)

    def almostEqual(self,n1, n2, epsilon=10**-4):
        return abs(n1-n2) < epsilon

    #gets dist between two coords
    def distance(self,x0, y0, x1, y1):
        dx = abs(x0 - x1)
        dy = abs(y0 - y1)
        return math.sqrt(dx**2 + dy**2)

    def distanceSq(self,x0, y0, x1, y1):
        dx = abs(x0 - x1)
        dy = abs(y0 - y1)
        return dx**2 + dy**2

    #gets random float between range
    def randomRange(self,min, max):
        return min + random.random()*(max-min)

    #gets weight random choice between two things
    def randomChoice(self,n1, n2, weight=0.5):
        return n1 if (random.random() < weight) else n2

    #get angles between two coords
    def getAngle(self,x, y, otherX, otherY):
        dy = y - otherY
        dx = otherX - x
        return math.atan2(dy, dx)

    def blitCenter(self,source, dest, location):
        rect = source.get_rect()
        rect.center = location
        dest.blit(source, rect)

    def isRectOutOfStage(self,data, x, y, w, h,width,height):
        #x,y -left upper cornern
        return (x<0 or y<0 or x+w > width or y+h > height)

    #pending on use
    #if I could finish the boat part earlier, I would add it to the project
    #break string down into lines no longer than maxWidth characters, does
    #not cut off words in the middle.This is for the additional information on painting
    def breakIntoLines(self,str,maxWidth):
        result = []
        words = str.split(" ")
        line = ""
        for word in words:
            if (len(line) + len(word) > maxWidth):
                result.append(line)
                line = ""
            line += word + " "
        result.append(line)
        return result

    def drawText(self,str, surface, x, y, font, color, center=False):
        label = font.render(str, 1, color)
        if center:
            Utils.blitCenter(label, surface, (x, y))
        else:
            surface.blit(label, (x, y))

    def drawMultilineText(self,str, surface, x,y, font, width, color, centerX=False):
        if len(str) <= width: 
            Utils.drawText(str, surface, x, y, font, color, centerX)
        else:
            lines = Utils.breakIntoLines(str, width)
            height = font.get_linesize()
            for i in range(len(lines)):
                Utils.drawText(lines[i], surface, x, y+i*height, 
                                font, color, centerX)