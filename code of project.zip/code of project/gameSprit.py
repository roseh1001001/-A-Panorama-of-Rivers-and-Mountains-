import pygame
import ImageWriter
#some extra functionalities for pygame sprites
#has mask collision, and calculating position on screen from scrolling
class GameSprite(pygame.sprite.Sprite):
    def __init__(self, data,x,y, img,time_passed,school):
        pygame.sprite.Sprite.__init__(self)
        self.img=img
        self.image = pygame.image.load(img).convert_alpha()
        self.rect = self.image.get_rect()
        #Makes the transparent parts of the Surface not set, and the opaque parts set.
        self.mask = pygame.mask.from_surface(self.image)
        self.x=x#in the (school) image's position
        self.y=y
        self.school = school
        self.background=data.newpglst[self.school-1]
        #self.ScreenX=self.background.rect.x

        self.width=ImageWriter.getWidth(self.background)
        self.screenX=1440-data.speed*(time_passed - data.timelst[self.school-1])
        self.updateScreenCoords()

    def updateScreenCoords(self):
         self.rect.x = self.x+self.screenX
         self.rect.y = self.y
         #in the screen's postion
         #it must be set in this way
         #because though the newpglst is comprised of surface, the surface transform to rect when I need it move using blit method



